SLStudio.Utils.RemoveHighlighting(get_param('nrhdlSignalDetection', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_nrhdlSignalDetection', 'handle'));
annotate_port('gm_nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 0/pipelinedMax', 0, 1, '');
annotate_port('nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 0/pipelinedMax', 0, 1, '');
annotate_port('gm_nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 1/pipelinedMax', 0, 1, '');
annotate_port('nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 1/pipelinedMax', 0, 1, '');
annotate_port('gm_nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 2/pipelinedMax', 0, 1, '');
annotate_port('nrhdlSignalDetection/SSB Detect and Demod/PSS Detector/Find Peak/filter peaks 2/pipelinedMax', 0, 1, '');
