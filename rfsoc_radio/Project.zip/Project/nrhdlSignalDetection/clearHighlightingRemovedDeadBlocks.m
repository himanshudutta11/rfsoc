SLStudio.Utils.RemoveHighlighting(get_param('nrhdlSignalDetection','Handle'));
